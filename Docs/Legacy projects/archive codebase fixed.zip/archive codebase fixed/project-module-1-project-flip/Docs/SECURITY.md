# Security

> You must never report security related issues, vulnerabilities or bugs to the issue tracker, or elsewhere in public. Instead sensitive bugs must be sent by email to <flippingindustries@gmail.com>. please include [ Github Security Issue] followed by a short discription of the issue in your title for the email.

If a vulnerability is reported, we will release a post stating whats effected and what the roadmap will be for fixing it. if you find an issue and would like to fix the vulnerability yourself, we encorage you to create and submit a pull request with a short description of your fix.