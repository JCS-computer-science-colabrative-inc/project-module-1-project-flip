# Project-FLIP

for setting up the dev environment, see the [installation.md](installation.md) in in the docs folder.