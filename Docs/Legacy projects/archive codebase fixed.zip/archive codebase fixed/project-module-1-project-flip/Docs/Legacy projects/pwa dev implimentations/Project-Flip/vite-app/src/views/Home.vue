<template>
    <div class="home">
        <img class="mx-auto" alt="Vue logo" src="../assets/logo.png" />
        <br />
        <HelloWorld
            msg="Welcome to flipping, this site is currently under construction"
        />
    </div>
</template>

<script>
// @ is an alias to /src
import HelloWorld from "@/components/HelloWorld.vue";

export default {
    name: "Home",
    components: {
        HelloWorld,
    },
};
</script>

<!--figure out a proper nav bar and footer here first, then get the rest of the content together-->
