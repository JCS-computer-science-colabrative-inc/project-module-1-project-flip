<template>
    <h1 class="text-3xl font-bold underline">
        If this is bold and underlined, then it means that Tailwind CSS is
        working!
    </h1>
</template>
        <style>
            body {
                background-color: rgba(0, 0, 0, 0.87);
                background-repeat: no-repeat;
                background-position: center;
                background-attachment: fixed;
                background-size: cover;
            }
            
        </style>

    <script>

    </script>



