<template>
    <div class="about">
        <h1>This is the signup page</h1>
    </div>
</template>

<script>
export default {};
</script>

<style></style>
