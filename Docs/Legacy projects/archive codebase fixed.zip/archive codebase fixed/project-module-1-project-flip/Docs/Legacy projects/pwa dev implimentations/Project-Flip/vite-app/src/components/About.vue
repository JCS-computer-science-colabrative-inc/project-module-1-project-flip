<template>
  <h1>
      This is the About Page
  </h1>
</template>

<script setup>

    import { useRouter } from 'vue-router'

    const router = useRouter()
</script>

<style>

</style>