# Assignment 2 

for setting up the dev environment, see the [installation.md](installation.md) in in the docs folder.
