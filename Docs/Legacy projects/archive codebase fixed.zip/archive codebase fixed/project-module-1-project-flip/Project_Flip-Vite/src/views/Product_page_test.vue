<template>
    <div class="text-center underline text-3xl font-bold">
        <h1>This is the test page for a product</h1>
    </div>
</template>

<script>
export default {};
</script>

<style></style>
